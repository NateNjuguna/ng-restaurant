import photoUrl from 'material-design-icons/social/svg/production/ic_person_48px.svg';

export default {
    age: 33,
    fullName: 'John Doe',
    firstName: 'John',
    lastName: 'Doe',
    gender: 'male',
    photoUrl
};