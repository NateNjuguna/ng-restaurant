# ng-restaurant
A simple restaurant application

# Deployment

to deploy the app, set NODE_ENV to 'production' and then run `npm start`. This will deploy
